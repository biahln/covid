# CovidMapper
One map of COVID - 19 in Brazil

Versão do Python = 3.6.4

 -> Tiago Braga Camargo Dias
    
    -> Para iniciar o projeto flask criado é necessário apenas executar o comando "pip install requirements.txt" que irá instalar todas as dependências do projeto.
    
    -> Após instalar as dependências execute o comando "python Main.py" a URL é "http://127.0.0.1:5000/covidmapper"
  
